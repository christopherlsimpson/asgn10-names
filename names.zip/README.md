#asgn10 - names

This program is an exercise for school to pratice PHP concepts: arrays, functions, and