<?php

function dd($value){

    echo"<pre>";
    var_dump($value);
    echo"</pre>";
    exit();
    
}

?>